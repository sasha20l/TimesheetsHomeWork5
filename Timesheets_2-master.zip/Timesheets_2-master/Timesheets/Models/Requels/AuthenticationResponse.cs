﻿using Microsoft.AspNetCore.Components.Authorization;

namespace Timesheets.Models.Requels
{
    public SessionDto
    {
        public AuthenticationStatus Status { get; set; }
    public SessionDto Session { get; set; }
}
}
    
}
