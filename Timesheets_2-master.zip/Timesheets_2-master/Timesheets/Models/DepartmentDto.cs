﻿namespace Timesheets.Models
{
    public class DepartmentDto
    {
        public int Id { get; set; }

        public string Description { get; set; }
    }
}