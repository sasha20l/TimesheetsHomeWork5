﻿namespace Timesheets.Models
{
    public class EmployeeTypeDto
    {
        public int Id { get; set; }
        public string Description { get; set; }

    }
}
