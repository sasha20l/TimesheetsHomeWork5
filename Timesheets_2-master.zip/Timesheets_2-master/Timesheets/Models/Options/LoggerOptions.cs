﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Timesheets.Models.Options 
{ public class LoggerOptions 
    { 
        public string Path { get; set; } 
    } 
}